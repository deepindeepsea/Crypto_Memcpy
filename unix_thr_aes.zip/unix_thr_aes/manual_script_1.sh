taskset -c 0,1 ./utp_tls 1048576 4000 &
taskset -c 2,3 ./utp_tls 1048576 4000 &
taskset -c 4,5 ./utp_tls 1048576 4000 &
taskset -c 6,7 ./utp_tls 1048576 4000 &
taskset -c 8,9 ./utp_tls 1048576 4000 &
taskset -c 10,11 ./utp_tls 1048576 4000 &
taskset -c 12,13 ./utp_tls 1048576 4000 &
taskset -c 14,15 ./utp_tls 1048576 4000 &
taskset -c 16,17 ./utp_tls 1048576 4000 & 
taskset -c 18,19 ./utp_tls 1048576 4000 &
taskset -c 20,21 ./utp_tls 1048576 4000 & 
taskset -c 22,23 ./utp_tls 1048576 4000 &
taskset -c 24,25 ./utp_tls 1048576 4000 & 
taskset -c 26,27 ./utp_tls 1048576 4000 &
taskset -c 28,29 ./utp_tls 1048576 4000 & 
taskset -c 30,31 ./utp_tls 1048576 4000 & 

#taskset -c 32,33 ./utp_tls 1048576 40 &
#taskset -c 34,35 ./utp_tls 1048576 40 &
#taskset -c 38,39 ./utp_tls 1048576 40 & taskset -c 36,37 ./utp_tls 1048576 40 & 

#taskset -c 40,41 ./utp_tls 1048576 40 & taskset -c 42,43 ./utp_tls 1048576 40 & taskset -c 44,45 ./utp_tls 1048576 40 & taskset -c 46,47 ./utp_tls 1048576 40 &
 
#taskset -c 48,49 ./utp_tls 1048576 40 & taskset -c 50,51 ./utp_tls 1048576 40 & taskset -c 52,53 ./utp_tls 1048576 40 & taskset -c 54,55 ./utp_tls 1048576 40 & 

#taskset -c 56,57 ./utp_tls 1048576 40 & taskset -c 58,59 ./utp_tls 1048576 40 & taskset -c 60,61 ./utp_tls 1048576 40 & taskset -c 62,63 ./utp_tls 1048576 40 &
