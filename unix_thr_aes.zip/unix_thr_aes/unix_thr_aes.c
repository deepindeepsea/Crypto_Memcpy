#define __STDC_FORMAT_MACROS	1
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <string.h>

#if defined(_POSIX_TIMERS) && (_POSIX_TIMERS > 0) &&                           \
	defined(_POSIX_MONOTONIC_CLOCK)
#define HAS_CLOCK_GETTIME_MONOTONIC
#endif

/* AES-GCM test data from NIST public test vectors */
#include <openssl/bio.h>
#include <openssl/evp.h>

static const unsigned char gcm_key[] = {
	0xee,0xbc,0x1f,0x57,0x48,0x7f,0x51,0x92,0x1c,0x04,0x65,0x66,
	0x5f,0x8a,0xe6,0xd1,0x65,0x8b,0xb2,0x6d,0xe6,0xf8,0xa0,0x69,
	0xa3,0x52,0x02,0x93,0xa5,0x72,0x07,0x8f
};

static const unsigned char gcm_iv[] = {
	0x99,0xaa,0x3e,0x68,0xed,0x81,0x73,0xa0,0xee,0xd0,0x66,0x84
};

static const unsigned char gcm_aad[] = {
	0x4d,0x23,0xc3,0xce,0xc3,0x34,0xb4,0x9b,0xdb,0x37,0x0c,0x43,
	0x7f,0xec,0x78,0xde
};

static void encrypt(void *buf, size_t buflen, size_t chunk_size)
{
	EVP_CIPHER_CTX *ctx;
	int outlen;
	int buflen_scary = (int) buflen;
	unsigned char *outbuf = malloc(chunk_size);

	ctx = EVP_CIPHER_CTX_new();
	/* Set cipher type and mode */
	EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL);

	/* Set IV length if default 96 bits is not appropriate */
	EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, sizeof(gcm_iv), NULL);

	/* Initialise key and IV */
	EVP_EncryptInit_ex(ctx, NULL, NULL, gcm_key, gcm_iv);

	/* Zero or more calls to specify any AAD */
	EVP_EncryptUpdate(ctx, NULL, &outlen, gcm_aad, sizeof(gcm_aad));

	/* Encrypt plaintext */
	EVP_EncryptUpdate(ctx, outbuf, &outlen, buf, buflen_scary);

	/* Finalise: note get no output for GCM */
	EVP_EncryptFinal_ex(ctx, outbuf + outlen, &outlen);

	/* Get tag */
	EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, outbuf);
	EVP_CIPHER_CTX_free(ctx);

	free(outbuf);
}

int main(int argc, char *argv[]) {
	int fds[2]; /* the pair of socket descriptors */
	int size;
	char *buf;
	int64_t count, i, delta;

#ifdef HAS_CLOCK_GETTIME_MONOTONIC
	struct timespec start, stop;
#else
	struct timeval start, stop;
#endif

	ssize_t sz = 0;

	if (argc < 3) {
		printf("usage: unix_thr <message-size> <message-count>\n");
		return 1;
	}

	size = atoi(argv[1]);
	count = atol(argv[2]);

	buf = malloc(size);
	if (buf == NULL) {
		perror("malloc");
		return 1;
	}


	printf("message size: %i octets\n", size);
	printf("message count: %"  PRId64  "\n", count);

	if (socketpair(AF_UNIX, SOCK_STREAM, 0, fds) == -1) {
		perror("socketpair");
		return 1;
	}

	if (!fork()) {
		/* child */
		for (i = 0; i < count; i++) {
			int read_size = size;
			char *tmp = buf;
retry:
			sz = read(fds[1], tmp, read_size);
			if (sz == read_size) {
				encrypt(buf, size, size);
				continue;
			}

			if (sz != size) {
				if (sz > 0) {
					read_size -= sz;
					tmp += sz;
					goto retry;
				} else {
					perror("read");
				}
			}
		}
	} else {
		/* parent */

		memset(buf, 'A', size);
#ifdef HAS_CLOCK_GETTIME_MONOTONIC
		if (clock_gettime(CLOCK_MONOTONIC, &start) == -1) {
			perror("clock_gettime");
			return 1;
		}
#else
		if (gettimeofday(&start, NULL) == -1) {
			perror("gettimeofday");
			return 1;
		}
#endif

		for (i = 0; i < count; i++) {
			if (write(fds[0], buf, size) != size) {
				perror("write");
				return 1;
			}
		}

#ifdef HAS_CLOCK_GETTIME_MONOTONIC
		if (clock_gettime(CLOCK_MONOTONIC, &stop) == -1) {
			perror("clock_gettime");
			return 1;
		}

		delta = ((stop.tv_sec - start.tv_sec) * 1000000 +
				(stop.tv_nsec - start.tv_nsec) / 1000);

#else
		if (gettimeofday(&stop, NULL) == -1) {
			perror("gettimeofday");
			return 1;
		}

		delta =
			(stop.tv_sec - start.tv_sec) * 1000000 + (stop.tv_usec - start.tv_usec);

#endif

		printf("average throughput: %" PRId64 " msg/s\n",
				(count * 1000000) / delta);
		printf("average throughput: %" PRId64 " Mb/s\n",
				(((count * 1000000) / delta) * size * 8) / 1000000);
	}

	return 0;
}
