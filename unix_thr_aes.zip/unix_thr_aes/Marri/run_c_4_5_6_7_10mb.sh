(for i in $(./cpus_of.sh  1 ); do  echo "cpu: $i "; taskset -c $i ./utp_tls  10485760  40000 & done;  wait ) > unix_thr_10mb.txt
