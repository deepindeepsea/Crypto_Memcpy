 time (for i in $(./cpus_of.sh 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15); do y=$((i+64)); echo "cpu: $i $y"; taskset -c $i,$y ./utp_tls 131072  40000 & done;  wait ) > unix_thr_aes_128k.txt
 sleep 5
 time (for i in $(./cpus_of.sh 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15); do y=$((i+64)); echo "cpu: $i $y"; taskset -c $i,$y ./utp_tls 524288  40000 & done;  wait ) > unix_thr_aes_512k.txt
 sleep 5
 time (for i in $(./cpus_of.sh 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15); do y=$((i+64)); echo "cpu: $i $y"; taskset -c $i,$y ./utp_tls 1048576 40000 & done;  wait ) > unix_thr_aes_1mb.txt
 sleep 5
 time (for i in $(./cpus_of.sh 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15); do y=$((i+64)); echo "cpu: $i $y"; taskset -c $i,$y ./utp_tls 10485760  40000 & done;  wait ) > unix_thr_aes_10mb.txt

