#!/bin/bash
(for i in $(seq 1 2 64); do y=$((i+64)); echo "cpu: $i $y"; taskset -c $i,$y ./utp_tls 10485760 40000 & done;  wait ) > unix_thr_aes_32_10mb.txt

