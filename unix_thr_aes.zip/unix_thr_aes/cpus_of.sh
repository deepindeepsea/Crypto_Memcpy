#!/bin/bash

# use with AMD + 16 numa zones 

while [ $# -gt 0 ]; do
        lscpu -p=cpu,node | grep ",$1$" | awk -F, '{print $1;}' | head -4
        shift
done
